using UnityEngine;
[ExecuteInEditMode]
[RequireComponent(typeof(Renderer))]
public class MeshLightmapSetting : MonoBehaviour
{
    public int lightmapIndex;
    public Vector4 lightmapScaleOffset;
    public void SaveSettings()
    {
        Renderer renderer = GetComponent<Renderer>();
        lightmapIndex = renderer.lightmapIndex;
        lightmapScaleOffset = renderer.lightmapScaleOffset;
    }
    public void LoadSettings()
    {
        Renderer renderer = GetComponent<Renderer>();
        renderer.lightmapIndex = lightmapIndex;
        renderer.lightmapScaleOffset = lightmapScaleOffset;
    }
    void Start()
    {
        LoadSettings();
        if (Application.isPlaying)
            Destroy(this);
    }
}