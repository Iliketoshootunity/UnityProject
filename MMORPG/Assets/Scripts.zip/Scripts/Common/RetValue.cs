using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RetValue  {
    public bool IsError;

    public string ErrorMsg;

    public object RetData;

}
