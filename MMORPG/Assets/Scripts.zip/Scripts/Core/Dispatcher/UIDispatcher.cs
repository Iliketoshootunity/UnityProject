using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIDispatcher : DispatcherBase<UIDispatcher, object[], string>
{


}
