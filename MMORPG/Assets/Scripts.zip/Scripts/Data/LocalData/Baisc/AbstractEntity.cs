using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AbstractEntity
{
    /// <summary>
    /// ID
    /// </summary>
    public int Id;
}
