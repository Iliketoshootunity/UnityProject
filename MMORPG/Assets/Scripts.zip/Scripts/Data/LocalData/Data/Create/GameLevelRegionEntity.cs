
//===================================================
//作    者：肖海林 
//创建时间：2018-11-06 16:39:25
//备    注：此代码为工具生成 请勿手工修改
//===================================================
using System.Collections;
/// <summary>
/// biao01实体
/// </summary>
 public partial class GameLevelRegionEntity : AbstractEntity
 {
	/// <summary>
	/// 游戏关卡Id
	/// </summary>
	public int GameLevelId { get; set; }
	/// <summary>
	/// 区域Id
	/// </summary>
	public int RegionId { get; set; }
	/// <summary>
	/// 初始化精灵
	/// </summary>
	public string InitSprite { get; set; }
  }
