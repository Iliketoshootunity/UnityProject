using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ��Ʒ��ʵ����
/// </summary>
public class ProductEntity : AbstractEntity
{
    /// <summary>
    /// ����
    /// </summary>
    public string Name;
    /// <summary>
    /// �۸�
    /// </summary>
    public float Price;
    /// <summary>
    /// ͼƬ����
    /// </summary>
    public string PciName;
    /// <summary>
    /// ����
    /// </summary>
    public string Des;

}
