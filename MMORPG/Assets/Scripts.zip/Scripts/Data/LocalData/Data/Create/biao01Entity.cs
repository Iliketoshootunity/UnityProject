
//===================================================
//作    者：肖海林 
//创建时间：2018-10-17 15:36:33
//备    注：此代码为工具生成 请勿手工修改
//===================================================
using System.Collections;
/// <summary>
/// biao01实体
/// </summary>
 public partial class biao01Entity : AbstractEntity
 {
	/// <summary>
	/// 商品名称
	/// </summary>
	public string Name { get; set; }
	/// <summary>
	/// 价格
	/// </summary>
	public float Price { get; set; }
	/// <summary>
	/// 图片名称
	/// </summary>
	public string PciName { get; set; }
	/// <summary>
	/// 注释
	/// </summary>
	public string Des { get; set; }
  }
