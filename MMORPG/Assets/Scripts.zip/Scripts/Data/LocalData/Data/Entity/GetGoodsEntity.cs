using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GetGoodsEntity
{
    public byte GoodsType;
    public int GoodsId;
    public int GoodsCount;
}
