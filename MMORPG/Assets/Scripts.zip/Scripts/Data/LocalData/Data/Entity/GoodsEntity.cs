using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoodsEntity
{
    /// <summary>
    /// Id
    /// </summary>
    public int GoodsId;

    /// <summary>
    /// ����
    /// </summary>
    public string GoodsName;

    /// <summary>
    /// ����
    /// </summary>
    public int GoodsProbability;

    /// <summary>
    /// ����
    /// </summary>
    public int GoodsCount;


}
