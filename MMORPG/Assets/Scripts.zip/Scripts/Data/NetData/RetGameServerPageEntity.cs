using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ��Ϸ��ҳǩ
/// </summary>
public class RetGameServerPageEntity 
{

    public int PageIndex;

    public string Name;

}
