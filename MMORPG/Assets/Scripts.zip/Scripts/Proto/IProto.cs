using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Э��Ļ���
/// </summary>
public interface IProto
{
    ushort ProtoCode { get; }

}
