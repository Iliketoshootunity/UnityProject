using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISystemCtrl  {

    void OpenView(UIViewType type);
}
