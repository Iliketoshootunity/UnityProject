using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// UI������ͼ����
/// </summary>
public class UISceneViewBase : UIViewBase
{
    /// <summary>
    /// �м䲿λ����
    /// </summary>
    public Transform ContainerCenter;

    /// <summary>
    /// HUD
    /// </summary>
    public bl_HUDText HUD;

}
