using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TipEntity  {

    /// <summary>
    /// 0 �Ǿ��� 1�ǽ��
    /// </summary>
    public int Type;

    /// <summary>
    /// ֵ
    /// </summary>
    public string Value;
}
